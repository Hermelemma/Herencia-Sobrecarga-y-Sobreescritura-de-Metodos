/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SobreEscritura;

/**
 *
 * @author em47a
 */
public class AvionSobreEscritura extends VehiculoSobreEscritura{

    public AvionSobreEscritura(String id, String marca, int modelo, String color) {
        super(id, marca, modelo, color);
    }
    
    @Override
    public String encender(){
        String a = "Mover switchs de energia, encender motor 1, mover la palanca de combustible de motor 1,"
                + " encender motor 2, mover la palanca de combustible de motor 2,"
                + " presionar los botones para utilizar la energia generada por los motores";
        return a;
    }
    
}