/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SobreEscritura;

/**
 *
 * @author em47a
 */
public class VehiculoSobreEscritura {
    
    private String id;
    private String marca;
    private int modelo;
    private String color;

    public VehiculoSobreEscritura(String id, String marca, int modelo, String color) {
        this.id = id;
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
    }
    
    public String encender(){
        return "Encendiendo el vehiculo";
    }
    
}
