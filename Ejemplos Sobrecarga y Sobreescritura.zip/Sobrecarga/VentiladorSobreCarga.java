/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SobreCarga;

/**
 *
 * @author em47a90
 */
public class VentiladorSobreCarga {
    
    private int noAspas;
    private String marca;
    private String color;

    public VentiladorSobreCarga() {
        this.noAspas = 0;
        this.marca = "";
        this.color = "";
    }    

    public VentiladorSobreCarga(int noAspas, String marca, String color) {
        this.noAspas = noAspas;
        this.marca = marca;
        this.color = color;
    }
    
    
    
}
